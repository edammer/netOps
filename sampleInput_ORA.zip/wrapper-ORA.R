﻿## Sample wrapper code for 2 network overrepresentation analysis (ORA)
# - netORA function requires packages WGCNA and biomaRt (if converting gene symbols across species from one network to the other)

rootdir=getwd()
setwd(rootdir)

load("./MEGA488_small-forORA.RData")
ls()
#[1] "cleanDatMEGA"    "MEsMEGA"         "netMEGA"         "numericMetaMEGA"
load("./5xFAD.Ananth.ProteinNetTMT.MMS10.pwr8-forORA.RData")
ls()
#[1] "cleanDat.5xFAD"    "MEs.5xFAD"         "net.5xFAD"         "numericMeta.5xFAD"


source("netORA.R")
netORA(cleanDatMEGA, cleanDat.5xFAD,
       netMEGA, net.5xFAD,
       species1="hsapiens", species2="mmusculus",
       outfiletitle="NatNeurosci2022brain_vs_5xFADmouseBrain_protein",
       heatmapTitle="Nat Neurosci (2022) Human Brain Protein Net vs 5xFAD Mouse Protein Net",
       net1.prefix="human",
       net2.prefix="mouse")



source("netORA.R")
netORA(cleanDat.5xFAD, cleanDatMEGA,
       net.5xFAD, netMEGA,
       species1="mmusculus", species2="hsapiens",
       outfiletitle="5xFADmouseBrain_vs_NatNeurosci2022brain-protein",
       heatmapTitle="5xFAD Mouse Protein Net vs Nat Neurosci (2022) Human Brain Protein Net",
       net1.prefix="mouse",
       net2.prefix="human")



load("./CohenRatOct2017-.RData")
#variables are cleanDat and net (for rat brain network)

netORA(cleanDat.5xFAD, cleanDat,
       net.5xFAD, net,
       species1="mmusculus", species2="rnorvegicus",
       outfiletitle="5xFADmouseBrain_vs_CohenRat2017brain-protein",
       heatmapTitle="5xFAD Mouse Protein Net vs Cohen Rat Brain (2017) Protein Net",
       net1.prefix="mouse",
       net2.prefix="rat")














inputDat1=cleanDatMEGA
inputDat2=cleanDat.5xFAD.Ananth
net1=netMEGA
net2=net.5xFAD.Ananth
species1="hsapiens"
species2="mmusculus"
outfiletitle="NatNeurosci2022brain_vs_5xFADmouseBrain_protein"
heatmapTitle="Nat Neurosci '22 Human Brain Protein Net vs 5xFAD Mouse Protein Net"
net1.prefix="human"
net2.prefix="mouse"